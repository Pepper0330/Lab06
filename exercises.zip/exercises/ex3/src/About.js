
function About(x){
    return (
        <div>
            <h1>{x.title}</h1>
            <p>About Us</p>
            <p>{x.desc}</p>
        </div>
    );
}

export default About;