import logo from './logo.svg';
import './App.css';
import Home from './Home.js';
import About from './About.js';
import Contact from './Contact.js';
import EngineeringTopics from './EngineeringTopics.js';

function App() {
  var isLoggedIn = false;


  var currentYear = new Date().getFullYear();
  return (
    <div>
      <EngineeringTopics />
    </div>
  );
}

export default App;
