
function Contact(x){
    return (
        <div>
            <h1>{x.title}</h1>
            <p>Contact Us</p>
            <p>{x.desc}</p>
        </div>
    );
}

export default Contact;