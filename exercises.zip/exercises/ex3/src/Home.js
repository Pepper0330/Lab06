
function Home(x){
    return (
        <div>
            <h1>{x.title}</h1>
            <p>Welcome to the Home Page</p>
            <p>{x.desc}</p>
        </div>
    );
}

export default Home;